import paho.mqtt.client as mqtt
import socket, time, os

INIM_IP = os.getenv("INIM_IP", "192.168.1.98")
INIM_PORT = int(os.getenv("INIM_PORT", "6004"))
USER_CODE = os.getenv("USER_CODE", "0001")
TCP_PASSWORD = os.getenv("TCP_PASSWORD", "")

MQTT_BROKER = os.getenv("MQTT_BROKER", "homeassistant")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
TOPIC_BASE = os.getenv("TOPIC_BASE", "inim/status")

def connect():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((INIM_IP, INIM_PORT))
    if TCP_PASSWORD:
        s.send((TCP_PASSWORD + "\r\n").encode())
    return s

def main():
    client = mqtt.Client()
    client.connect(MQTT_BROKER, MQTT_PORT, 60)
    client.loop_start()
    while True:
        try:
            sock = connect()
            while True:
                data = sock.recv(1024)
                if not data:
                    break
                client.publish(TOPIC_BASE, data.hex())
        except Exception as e:
            print("Error:", e)
            time.sleep(5)

if __name__ == "__main__":
    main()
